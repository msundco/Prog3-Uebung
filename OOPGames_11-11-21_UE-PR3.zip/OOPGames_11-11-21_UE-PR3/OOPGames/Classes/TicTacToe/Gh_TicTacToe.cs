﻿/*
Gruppe H

AUfteilung:
    -Human Player: Fabian & Julian
    -Rules: Michael
    -Computer Player: ___
    ...
*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace OOPGames.Classes.TicTacToe
{
    class Gh_TicTacToe
    {
        //printf("Hello WOrld\n");
    }
}
